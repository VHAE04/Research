How to install.
 Run `install.bat' with administrator privileges.

Notes
 Priority is given to copying to the 64-bit version.
